import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

import Add from './components/Add';
import List from './components/List';
import Pay from './components/Pay';
import Button from './components/core/Button';

class App extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            activeTab: 'add',
            items: []
        };
    }

    onClickTabAdd() {
        this.setState({
            activeTab: 'add'
        });
    }
    onClickTabList() {
        this.setState({
            activeTab: 'list'
        });
    }
    onClickTabPay() {
        this.setState({
            activeTab: 'pay'
        });
    }
    renderTabAdd() {
        if (this.state.activeTab ==='add') {
            return (
                <Add />
            );
        }
    }
        render() {
            return (

        
            <div className='container-fluid'>
                <div className='row'>
                    <Button>Add</Button>
                    <Button>List</Button>
                    <Button>Pay</Button>
                </div>

                <div className='row'>
                   {this.renderTabAdd()}
                   {this.renderTabList()}
                   {this.renderTabPay()}         
                </div>
            </div>
        );    
        
    }
}
export default App;